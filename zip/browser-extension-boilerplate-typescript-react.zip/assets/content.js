import{B as r}from"./browser-polyfill.js";import"./_commonjsHelpers.js";alert(r.runtime.id);

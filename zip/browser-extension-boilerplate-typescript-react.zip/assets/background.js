import{B as t}from"./browser-polyfill.js";import"./_commonjsHelpers.js";(async function(){const o=await t.tabs.query({active:!0});console.log(o)})();
